package ecom;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Acessories {
	  JFrame frame;
	    DefaultListModel<String> cartModel;
	    JList<String> productList;
	    JTextArea cartTextArea;

	    List<Product> products;
	    double totalPrice;
	    double changeprice;

		public Acessories() {
	        frame = new JFrame("E-Commerce Application");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(800, 600);

	        products = new ArrayList<>();
	        products.add(new Product("Belts", 10));
	        products.add(new Product("Bracelets ", 150));
	        products.add(new Product("Brooches ", 599));
	        products.add(new Product("Cufflinks", 89));
	        products.add(new Product("Earrings", 19));
	        products.add(new Product("Eyeglasses ", 159));
	        products.add(new Product("Face masks ", 59));
	        products.add(new Product("Gloves", 89));
	        products.add(new Product("Handbags", 1099));
	        products.add(new Product("Hats ", 19));
	        products.add(new Product("Hair accessories", 599));
	        products.add(new Product("Helmets", 899));
	        products.add(new Product("Handkerchiefs", 19));
	        products.add(new Product("Luggage ", 1599));
	        products.add(new Product("Necklaces ", 599));
	        products.add(new Product("Neckties", 89));
	        products.add(new Product("Pocket squares", 109));
	        products.add(new Product("Rings ", 1699));
	        products.add(new Product("Scarves ", 59));
	        products.add(new Product("Sunglasses", 899));
	        

	        cartModel = new DefaultListModel<>();
	        productList = new JList<>(products.stream().map(Product::getName).toArray(String[]::new));
	        productList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	        productList.addListSelectionListener(e -> {
	            int selectedIndex = productList.getSelectedIndex();
	            System.out.println("selectedproduct"+cartModel);
	            if (selectedIndex != -1) {
	                Product selectedProduct = products.get(selectedIndex);
	                cartModel.addElement(selectedProduct.getName() + " - $" + selectedProduct.getPrice());
	                totalPrice += selectedProduct.getPrice();
	                changeprice=totalPrice/2;
	                updateCartTextArea();
	            }
	        });

	        JScrollPane productScrollPane = new JScrollPane(productList);
	        productScrollPane.setPreferredSize(new Dimension(300, 400));

	        cartTextArea = new JTextArea(10, 30);
	        cartTextArea.setEditable(false);

	        JScrollPane cartScrollPane = new JScrollPane(cartTextArea);
	        
	        JButton back=new JButton(new ImageIcon("back.jpg"));
	        back.setBounds(1380,470,120,40);
	        back.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					Allbutton a11=new Allbutton();
					
				}
	        	
	        });


	        JButton checkoutButton = new JButton(new ImageIcon("Proceed to Buy.jpg"));
	        checkoutButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	radiobuttonnu clicko=new radiobuttonnu();
	               // JOptionPane.showMessageDialog(frame, "Total Price: $" + totalPrice, "successfully buyed", JOptionPane.INFORMATION_MESSAGE);
	            }
	        });

	        JPanel panel = new JPanel();
	        panel.setLayout(new BorderLayout());
	        panel.add(back);
	        panel.add(productScrollPane, BorderLayout.WEST);
	        panel.add(cartScrollPane, BorderLayout.CENTER);
	        panel.add(checkoutButton, BorderLayout.SOUTH);
	       
	        
	        frame.setSize(1650,600);

	        frame.add(panel);
	        frame.setVisible(true);
	    }

	    public void updateCartTextArea() {
	        cartTextArea.setText("Shopping Cart:\n");
	        for (int i = 0; i < cartModel.getSize(); i++) {
	            cartTextArea.append(cartModel.getElementAt(i) + "\n");
	        }
	        cartTextArea.append("\nTotal Price: $" + changeprice);
	    }

	    public static void main(String[] args) {
	    	SwingUtilities.invokeLater(() -> new Acessories());
	        
	    }

	    private static class Product {
	        private String name;
	        private double price;

	        public Product(String name, double price) {
	            this.name = name;
	            this.price = price;
	        }

	        public String getName() {
	            return name;
	        }

	        public double getPrice() {
	            return price;
	        }
	    }
	



}
