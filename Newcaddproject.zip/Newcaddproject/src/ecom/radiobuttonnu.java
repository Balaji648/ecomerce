package ecom;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;    

public class radiobuttonnu {
	
	JFrame f;
	
	
	radiobuttonnu(){    
		f=new JFrame();
		JLabel klo=new JLabel("CHOOSE YOUR PAYMENT METHOD");
		klo.setBounds(560,20,300,300);
		
		
		
		
		
		
		JButton proc=new JButton(new ImageIcon("Proceed.jpg"));
		proc.setBounds(600,350,120,35);
		
		proc.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Addresscontact iop=new Addresscontact();
			}
			
		});
	JRadioButton r1=new JRadioButton("online payment");    
	JRadioButton r2=new JRadioButton("cash on delivery");
	JButton proc2=new JButton("ok");
	proc2.setBounds(600,400,120,35);
	proc2.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		
		String opio1= r1.isSelected()?"online":"cash";
		System.out.println("selected"+opio1);
		
		
		}
	});
	
	r1.setBounds(600,200,200,60);    
	r2.setBounds(600,250,200,60);    
	ButtonGroup bg=new ButtonGroup();    
	bg.add(r1);bg.add(r2);   
	f.add(r1);f.add(r2);
	f.add(klo);
	f.add(r2);
	f.add(proc);
	f.add(proc2);
	f.setSize(1650,600);    
	f.setLayout(null);    
	f.setVisible(true);    
	}    
	public static void main(String[] args) {    
		new radiobuttonnu(); 
		
	
	}    }   




	


