package ecom;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Mobiles {
	  JFrame frame;
	    DefaultListModel<String> cartModel;
	    JList<String> productList;
	    JTextArea cartTextArea;

	    List<Product> products;
	    double totalPrice;
	    double changeprice;
	    
		public Mobiles() {
	        frame = new JFrame("E-Commerce Application");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(800, 600);

	        products = new ArrayList<>();
	        products.add(new Product("Samsung Galaxy S23 Ultra 5G",25000));
	        products.add(new Product("Apple iPhone 14 Pro Max ", 20000));
	        products.add(new Product("Google Pixel 8 ",20000));
	        products.add(new Product("OnePlus 11 Pro", 1899));
	        products.add(new Product("Xiaomi 13 Pro", 10999));
	        products.add(new Product("Oppo Find X7 Pro ", 15999));
	        products.add(new Product("Vivo X90 Pro+", 59099));
	        products.add(new Product("Realme GT Neo 5", 89099));
	        products.add(new Product("Poco F5 Pro", 10099));
	        products.add(new Product("iQOO Neo 7 Pro", 159099));
	        products.add(new Product(" Honor Magic 5 Pro", 56799));
	        products.add(new Product("Motorola Edge+ (2023)", 89899));
	        products.add(new Product("Sony Xperia 1 IV", 10799));
	        products.add(new Product("Asus ROG Phone 7 ", 15399));
	        products.add(new Product("Nubia Z40 Pro", 57699));
	        products.add(new Product("Black Shark 5 Pro", 80999));
	        products.add(new Product("ZTE Axon 40 Ultra", 76599));
	        products.add(new Product("Meizu 20 Pro", 15999));
	        products.add(new Product("OnePlus Nord CE 3 Lite 5G ", 50999));
	        products.add(new Product("Realme Narzo 60 5G", 86499));
	        
	        

	        cartModel = new DefaultListModel<>();
	        productList = new JList<>(products.stream().map(Product::getName).toArray(String[]::new));
	        productList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	        productList.addListSelectionListener(e -> {
	            int selectedIndex = productList.getSelectedIndex();
	            if (selectedIndex != -1) {
	                Product selectedProduct = products.get(selectedIndex);
	                cartModel.addElement(selectedProduct.getName() + " - $" + selectedProduct.getPrice());
	                totalPrice += selectedProduct.getPrice();
	                changeprice=totalPrice/2;
	                updateCartTextArea();
	            }
	        });

	        JScrollPane productScrollPane = new JScrollPane(productList);
	        productScrollPane.setPreferredSize(new Dimension(300, 400));

	        cartTextArea = new JTextArea(10, 30);
	        cartTextArea.setEditable(false);

	        JScrollPane cartScrollPane = new JScrollPane(cartTextArea);
	        
	        JButton back=new JButton(new ImageIcon("back.jpg"));
	        back.setBounds(1380,470,120,40);
	        back.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					Allbutton a10=new Allbutton();
					
				}
	        	
	        });

	        

	        JButton checkoutButton = new JButton(new ImageIcon("Proceed to Buy.jpg"));
	        checkoutButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	radiobuttonnu clicko=new radiobuttonnu();
	               // JOptionPane.showMessageDialog(frame, "Total Price: $" + totalPrice, "successfully buyed", JOptionPane.INFORMATION_MESSAGE);
	            }
	        });

	        JPanel panel = new JPanel();
	        panel.setLayout(new BorderLayout());
	        panel.add(back);
	        panel.add(productScrollPane, BorderLayout.WEST);
	        panel.add(cartScrollPane, BorderLayout.CENTER);
	        panel.add(checkoutButton, BorderLayout.SOUTH);
	        
	        frame.setSize(1650,600);

	        frame.add(panel);
	        frame.setVisible(true);
	    }

	    public void updateCartTextArea() {
	        cartTextArea.setText("Shopping Cart:\n");
	        for (int i = 0; i < cartModel.getSize(); i++) {
	            cartTextArea.append(cartModel.getElementAt(i) + "\n");
	        }
	        cartTextArea.append("\nTotal Price: $" + changeprice);
	    }

	    public static void main(String[] args) {
	    	SwingUtilities.invokeLater(() -> new Mobiles());
	        
	    }

	    private static class Product {
	        private String name;
	        private double price;

	        public Product(String name, double price) {
	            this.name = name;
	            this.price = price;
	        }

	        public String getName() {
	            return name;
	        }

	        public double getPrice() {
	            return price;
	        }
	    }
	



}
