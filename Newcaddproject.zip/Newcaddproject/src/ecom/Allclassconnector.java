package ecom;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Allclassconnector {
	 private JFrame frame;
	    private JButton openButton;
	    private ImageIcon image;
	    
	    public Allclassconnector() {
	    	
	        frame = new JFrame("Ecommerce Application");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(400, 300);
	        
	        JLabel frontpage=new JLabel("WELCOME TO SHOPPING ");
	        frontpage.setBounds(640,180,400,30);
	        openButton = new JButton(new ImageIcon("Welcometoshopping.jpg"));
	        openButton.setBounds(660,210,100,30);
	        openButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                Nextframe();
	            }
	        });
	        JButton design=new JButton(new ImageIcon("Design image.jpg"));
	        design.setBounds(580,300,300,300);

	        JPanel panel = new JPanel();
	        panel.setLayout(null);
	        panel.add(frontpage);
	        panel.add(openButton);
	        panel.add(design);
	        
	        frame.setSize(1650,1080);
	        frame.add(panel);
	        frame.setVisible(true);
	    }

	    public void Nextframe() {
	        JFrame newFrame = new JFrame("Ecommerce Application");
	        newFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        newFrame.setSize(400, 300);

	        JLabel label = new JLabel("EXPLORE NEW THING TO SHOPPING ");
	        label.setBounds(650,180,400,30);
	        JButton prototype =new JButton(new ImageIcon("Clicktocontinue.jpg"));
	        prototype.setBounds(660,210,200,60);
	        prototype.addActionListener(new ActionListener() {
	  	        						@Override
					public void actionPerformed(ActionEvent e) {
	  	        					Allbutton success=new Allbutton();
						
					}
	        	
	        });
	        
	        JButton showcase=new JButton(new ImageIcon("Showcase.jpg"));
	        showcase.setBounds(610,300,300,300);
	        
	        newFrame.setSize(1650,1080);
	        JPanel panel = new JPanel();
	        panel.add(showcase);
	        panel.setLayout(null);
	        panel.add(label);
	        panel.add(prototype);

	        newFrame.add(panel);
	        newFrame.setVisible(true);
	    }

	    public static void main(String[] args) {
	        SwingUtilities.invokeLater(() -> new Allclassconnector());
	    }
	


}
