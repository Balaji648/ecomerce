package ecom;

import javax.swing.*;

import ecom.ecommercemodified.Product;

public class Billing {
	public static void bil() {
	JFrame gho=new JFrame("billing");
	JButton tick=new JButton(new ImageIcon("Tick.jpg"));
	tick.setBounds(600,40,300,300);
	
	JLabel namee=new JLabel("Your Order Was Succesfully Buyed ");
	JLabel namee2=new JLabel("Delivery Within 7 Days ");
	
	namee.setBounds(640,100,500,500);
	namee2.setBounds(670,120,500,500);
	gho.setSize(1650,600);
	gho.setLayout(null);
	gho.setVisible(true);
	gho.add(tick);
	gho.add(namee);
	gho.add(namee2);
	
	
	}
		public static void main(String[] args) {
			bil();
		}

	
			
}

	
