package ecom;
//import java.util.Scanner;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Addresscontact {
	public Addresscontact() {
	//	Scanner iu=new Scanner(System.in);
	JFrame er=new JFrame();
	JLabel number = new JLabel("NUMBER");
	number.setBounds(400,100, 200,30);
	JTextField t1=new JTextField();
//	t1.addActionListener(new ActionListener() {
//
//		@Override
//		public void actionPerformed(ActionEvent e) {
//			String input=t1.getText();
//			
//		}
//		
//	});
//	
	
	//int number = iu.nextInt();
	JLabel addoco = new JLabel("ADD YOUR NUMBER AND ADDRESS");
   addoco.setBounds(650,20,400,70);

	JLabel address = new JLabel("ADDRESS");
	address.setBounds(400,200,200,30);
	JTextField t2=new JTextField();
	JButton done = new JButton(new ImageIcon("save.jpg"));
	done.setBounds(540,280, 120,30);
	done.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			String num=t1.getText();
			String addr=t2.getText();
			System.out.println("mobile number :"+num);
			System.out.println("Adress : "+addr);
			JOptionPane.showMessageDialog(er, t1.getText(),"successfully saved" ,JOptionPane.INFORMATION_MESSAGE);
			
			JOptionPane.showMessageDialog(er, t2.getText(),"successfully saved" ,JOptionPane.INFORMATION_MESSAGE);
			
		}
		
	});
	JButton placeorder=new JButton(new ImageIcon("placetoorder.jpg"));
	placeorder.setBounds(800,170,140,45);
	placeorder.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			Billing bill=new Billing();
			bill.bil();
			
		}
		
	});
	
	//String address=iu.next();
	t1.setBounds(500,100, 200,30);
	t2.setBounds(500,200, 200,60);
	er.setSize(1650,600);
	er.add(addoco);
	er.add(placeorder);
	er.add(done);
	er.add(number);
	er.add(address);
	er.add(t1);
	er.add(t2);
	er.setLayout(null);
	er.setVisible(true);
	}
	public static void main(String[] args) {
		new Addresscontact();
	}
	}


