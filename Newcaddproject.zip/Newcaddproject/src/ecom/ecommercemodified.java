package ecom;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ecommercemodified {
	  JFrame frame;
	    DefaultListModel<String> cartModel;
	    static JList<String> productList;
	    JTextArea cartTextArea;

	    List<Product> products;
	    double totalPrice;
	    double changeprice;
	   


		public ecommercemodified() {
	        frame = new JFrame("E-Commerce Application");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(800, 600);
	        JLabel ko =new JLabel("BRANED SHOES AND BAGS");

	        products = new ArrayList<>();
	        
	        products.add(new Product("Nike Blazer Mid '77: ", 85));
	        products.add(new Product("Nike Women’s W Air Zoom Structure 24 Running Shoe ", 120));
	        products.add(new Product("BATA Men’s William E Uniform Dress Shoe ",30));
	        products.add(new Product("Adidas Unisex-Adult Ultrabounce Running Shoe ", 120));
	        products.add(new Product("BATA Men’s William E Uniform Dress Shoe", 30));
	        products.add(new Product("Puma Unisex-Adult Electron E Running Shoe", 60));
	        products.add(new Product("Nike Blazer  ",85));
	        products.add(new Product("Nike Blazer Low Platform ",100));
	        products.add(new Product("Nike Daybreak ", 95));
	        products.add(new Product("Adidas Originals Men’s Superstar Sneaker ",80));
	        products.add(new Product("Converse Chuck Taylor All Star High Top Sneaker", 55));
	        products.add(new Product("Vans Old Skool Skate Shoes",60));
	        products.add(new Product("New Balance Men’s 990v5 Sneaker ", 175));
	        products.add(new Product("Gucci GG Marmont Matelassé Leather Super Mini Bag ", 890));
	        products.add(new Product("Louis Vuitton Neverfull MM Tote Bag",1500));
	        products.add(new Product("Chanel Classic Flap Bag", 800));
	        products.add(new Product("Prada Galleria Saffiano Leather Tote Bag", 2500));
	        products.add(new Product("Saint Laurent Loulou Small Leather Shoulder Bag ", 2000));
	        products.add(new Product("Fendi Peekaboo Regular Leather Satchel Bag ",4500));
	        products.add(new Product("Hermès Birkin Bag",9000));
	        products.add(new Product("Bottega Veneta The Pouch Clutch Bag",2700));
	        

	        cartModel = new DefaultListModel<>();
	        productList = new JList<>(products.stream().map(Product::getName).toArray(String[]::new));
	        productList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	        productList.addListSelectionListener(e -> {
	            int selectedIndex = productList.getSelectedIndex();
	            System.out.println("selectedproduct"+cartModel);
	            if (selectedIndex != -1) {
	                Product selectedProduct = products.get(selectedIndex);
	                cartModel.addElement(selectedProduct.getName() + " - $" + selectedProduct.getPrice());
	                totalPrice += selectedProduct.getPrice();
	                changeprice=totalPrice/2;
	                updateCartTextArea();
	            }
	            
	            	
	        });
	        
	        
	     

	        JScrollPane productScrollPane = new JScrollPane(productList);
	        productScrollPane.setPreferredSize(new Dimension(300, 400));

	        cartTextArea = new JTextArea(10, 30);
	        cartTextArea.setEditable(false);

	        JScrollPane cartScrollPane = new JScrollPane(cartTextArea);
	        
	        JButton back=new JButton(new ImageIcon("back.jpg"));
	        back.setBounds(1380,470,120,40);
	        
	        back.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					Allbutton a8=new Allbutton();
					
				}
	        	
	        });

	        JButton checkoutButton = new JButton(new ImageIcon("Proceed to Buy.jpg"));
	        checkoutButton.addActionListener(new ActionListener() {
	        	
	            public void actionPerformed(ActionEvent e) {
	                radiobuttonnu clicko=new radiobuttonnu();
	            	
	                //JOptionPane.showMessageDialog(frame, "Total Price: $" + totalPrice, "successfully buyed", JOptionPane.INFORMATION_MESSAGE);
	                
	            }
	        });
	        JPanel panel = new JPanel();
	        panel.setLayout(null);
	        panel.add(back);
	        panel.setLayout(new BorderLayout());
	        panel.add(productScrollPane, BorderLayout.WEST);
	        panel.add(cartScrollPane, BorderLayout.CENTER);
	        panel.add(checkoutButton, BorderLayout.SOUTH);
	        frame.setSize(1650,600);
	        frame.add(panel);
	        frame.setVisible(true);
	    }

		public void updateCartTextArea() {
	        cartTextArea.setText("Shopping Cart:\n");
	        for (int i = 0; i < cartModel.getSize(); ++i) {
	       // while(true) {
	        //if(0<cartModel.getSize()) {
	        	//cartTextArea.append(cartModel.getElementAt() + "\n");
	        	//break;
	        //}
	        //}
	           cartTextArea.append(cartModel.getElementAt(i) + "\n");
	        }
	        cartTextArea.append("\nTotal Price: $" + changeprice);
	    }
		
		public void listofproduct() {
			cartModel.getClass();
		}

	    public static void main(String[] args) {
	    	SwingUtilities.invokeLater(() -> new ecommercemodified());
	        
	    }

	    public static class Product {
	        private String name;
	        private double price;

	        public Product(String name, double price) {
	            this.name = name;
	            this.price = price;
	        }

	        public String getName() {
	            return name;
	        }

	        public double getPrice() {
	            return price;
	        }
	        
	       
	    }

		
		
	


	

}
