package ecom;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Laptop {
	  JFrame frame;
	    DefaultListModel<String> cartModel;
	    JList<String> productList;
	    JTextArea cartTextArea;

	    List<Product> products;
	    double totalPrice;
	    double changeprice;
	
		public Laptop() {
	        frame = new JFrame("E-Commerce Application");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(800, 600);

	        products = new ArrayList<>();
	        products.add(new Product("Apple MacBook", 109999));
	        products.add(new Product("Dell XPS ", 159999));
	        products.add(new Product("HP Spectre ", 59999));
	        products.add(new Product("Lenovo ThinkPad", 89999));
	        products.add(new Product("Microsoft Surface", 109999));
	        products.add(new Product("Asus ZenBook ", 159999));
	        products.add(new Product("Acer Swift", 59999));
	        products.add(new Product("Razer Blade", 89999));
	        products.add(new Product("MSI Stealth", 109999));
	        products.add(new Product("Gigabyte Aero ", 159999));
	        products.add(new Product("Samsung Galaxy Book", 59999));
	        products.add(new Product("Huawei MateBook", 89999));
	        products.add(new Product("Xiaomi Mi Notebook", 109999));
	        products.add(new Product("Honor MagicBook ", 159999));
	        products.add(new Product("Acer Predator ", 59999));
	        products.add(new Product("Asus ROG", 89999));
	        products.add(new Product("Dell Alienware", 109999));
	        products.add(new Product("HP Omen", 159999));
	        products.add(new Product("Lenovo Legion", 59999));
	        products.add(new Product("MSI GE", 89999));
	        products.add(new Product("Gigabyte Aorus", 10999));
	        products.add(new Product("Samsung Odyssey ", 15999));
	        products.add(new Product("Huawei MateBook X Pro ", 59999));
	        products.add(new Product("Xiaomi Mi Notebook Pro", 8999));
	        

	        cartModel = new DefaultListModel<>();
	        productList = new JList<>(products.stream().map(Product::getName).toArray(String[]::new));
	        productList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	        productList.addListSelectionListener(e -> {
	            int selectedIndex = productList.getSelectedIndex();
	            
	            System.out.println("selectedproduct"+cartModel);
	            
	            if (selectedIndex != -1) {
	                Product selectedProduct = products.get(selectedIndex);
	                cartModel.addElement(selectedProduct.getName() + " - $" + selectedProduct.getPrice());
	                totalPrice += selectedProduct.getPrice();
	                changeprice=totalPrice/2;
	                updateCartTextArea();
	            }
	        });

	        JScrollPane productScrollPane = new JScrollPane(productList);
	        productScrollPane.setPreferredSize(new Dimension(300, 400));

	        cartTextArea = new JTextArea(10, 30);
	        cartTextArea.setEditable(false);

	        JScrollPane cartScrollPane = new JScrollPane(cartTextArea);
	        
	        JButton back=new JButton(new ImageIcon("back.jpg"));
	        back.setBounds(1380,470,120,40);
	        back.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					Allbutton a12=new Allbutton();
					
				}
	        	
	        });


	        JButton checkoutButton = new JButton(new ImageIcon("Proceed to Buy.jpg"));
	        checkoutButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	radiobuttonnu clicko=new radiobuttonnu();
	               // JOptionPane.showMessageDialog(frame, "Total Price: $" + totalPrice, "successfully buyed", JOptionPane.INFORMATION_MESSAGE);
	            }
	        });

	        JPanel panel = new JPanel();
	        panel.setLayout(new BorderLayout());
	        panel.add(back);
	        panel.add(productScrollPane, BorderLayout.WEST);
	        panel.add(cartScrollPane, BorderLayout.CENTER);
	        panel.add(checkoutButton, BorderLayout.SOUTH);
	        
	        
	        frame.setSize(1650,600);

	        frame.add(panel);
	        frame.setVisible(true);
	    }

	    public void updateCartTextArea() {
	        cartTextArea.setText("Shopping Cart:\n");
	        for (int i = 0; i < cartModel.getSize(); i++) {
	            cartTextArea.append(cartModel.getElementAt(i) + "\n");
	        }
	        cartTextArea.append("\nTotal Price: $" + changeprice);
	    }

	    public static void main(String[] args) {
	    	SwingUtilities.invokeLater(() -> new Laptop());
	        
	    }

	    private static class Product {
	        private String name;
	        private double price;

	        public Product(String name, double price) {
	            this.name = name;
	            this.price = price;
	        }

	        public String getName() {
	            return name;
	        }

	        public double getPrice() {
	            return price;
	        }
	    }
	


}
