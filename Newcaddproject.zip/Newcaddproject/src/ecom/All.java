package ecom;
import javax.swing.*;

import ecom.ecommercemodified.Product;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class All {
	  JFrame frame;
	    DefaultListModel<String> cartModel;
	    JList<String> productList;
	    JTextArea cartTextArea;

	    List<Product> products;
	    double totalPrice;
	    double changeprice;
	    
	    void selected() {
        	
			System.out.println("selectedproduct"+cartModel);
		
    }
   
	   


		public All() {
	        frame = new JFrame("E-Commerce Application");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(800, 600);

	        products = new ArrayList<>();
	       
	        products.add(new Product("Nike Blazer Mid '77: ", 85));
	        products.add(new Product("Nike Women’s W Air Zoom Structure 24 Running Shoe ", 120));
	        products.add(new Product("BATA Men’s William E Uniform Dress Shoe ",30));
	        products.add(new Product("Adidas Unisex-Adult Ultrabounce Running Shoe ", 120));
	        products.add(new Product("BATA Men’s William E Uniform Dress Shoe", 30));
	        products.add(new Product("Puma Unisex-Adult Electron E Running Shoe", 60));
	        products.add(new Product("Nike Blazer  ",85));
	        products.add(new Product("Nike Blazer Low Platform ",100));
	        products.add(new Product("Nike Daybreak ", 95));
	        products.add(new Product("Adidas Originals Men’s Superstar Sneaker ",80));
	        products.add(new Product("Converse Chuck Taylor All Star High Top Sneaker", 55));
	        products.add(new Product("Vans Old Skool Skate Shoes",60));
	        
	        
	        products.add(new Product("Strip shirt green", 100));
	        products.add(new Product(" black shirt", 200));
	        products.add(new Product("white shirt ", 500));
	        products.add(new Product("whited black checked", 350));
	        products.add(new Product("blue party wear", 400));
	        products.add(new Product("blue jean ",678));
	        products.add(new Product("ice blue jean ", 500));
	        products.add(new Product("fadded jean", 800));
	        products.add(new Product("trendy shirts of grey", 430));
	        products.add(new Product("cotton shirt ", 430));
	        products.add(new Product("Lycra shirt",340));
	        products.add(new Product("lycra ice blue shirt",320));
	        products.add(new Product("lycra blue",659));
	        products.add(new Product("Tonned Shirt ", 1599));
	        products.add(new Product("Jean Shirt ", 599));
	        products.add(new Product("Polofit Tshirt", 899));
	        products.add(new Product("Lycra Tshirt", 1099));
	        products.add(new Product("full Hand shirt ", 599));
	        products.add(new Product("HalfHand partywear ", 300));
	        
	        
	        products.add(new Product("Samsung Galaxy S23 Ultra 5G",25000));
	        products.add(new Product("Apple iPhone 14 Pro Max ", 20000));
	        products.add(new Product("Google Pixel 8 ",20000));
	        products.add(new Product("OnePlus 11 Pro", 1899));
	        products.add(new Product("Xiaomi 13 Pro", 10999));
	        products.add(new Product("Oppo Find X7 Pro ", 15999));
	        products.add(new Product("Vivo X90 Pro+", 59099));
	        products.add(new Product("Realme GT Neo 5", 89099));
	        products.add(new Product("Poco F5 Pro", 10099));
	        products.add(new Product("iQOO Neo 7 Pro", 159099));
	        products.add(new Product(" Honor Magic 5 Pro", 56799));
	        products.add(new Product("Motorola Edge+ (2023)", 89899));
	        products.add(new Product("Sony Xperia 1 IV", 10799));
	        products.add(new Product("Asus ROG Phone 7 ", 15399));
	        products.add(new Product("Nubia Z40 Pro", 57699));
	        products.add(new Product("Black Shark 5 Pro", 80999));
	        products.add(new Product("ZTE Axon 40 Ultra", 76599));
	        products.add(new Product("Meizu 20 Pro", 15999));
	        products.add(new Product("OnePlus Nord CE 3 Lite 5G ", 50999));
	        products.add(new Product("Realme Narzo 60 5G", 86499));
	        
	        
	        products.add(new Product("Belts", 10));
	        products.add(new Product("Bracelets ", 150));
	        products.add(new Product("Brooches ", 599));
	        products.add(new Product("Cufflinks", 89));
	        products.add(new Product("Earrings", 19));
	        products.add(new Product("Eyeglasses ", 159));
	        products.add(new Product("Face masks ", 59));
	        products.add(new Product("Gloves", 89));
	        products.add(new Product("Handbags", 1099));
	        products.add(new Product("Hats ", 19));
	        products.add(new Product("Hair accessories", 599));
	        products.add(new Product("Helmets", 899));
	        products.add(new Product("Handkerchiefs", 19));
	        products.add(new Product("Luggage ", 1599));
	        products.add(new Product("Necklaces ", 599));
	        products.add(new Product("Neckties", 89));
	        products.add(new Product("Pocket squares", 109));
	        products.add(new Product("Rings ", 1699));
	        products.add(new Product("Scarves ", 59));
	        products.add(new Product("Sunglasses", 899));
	        
	        
	        products.add(new Product("Apple MacBook", 109999));
	        products.add(new Product("Dell XPS ", 159999));
	        products.add(new Product("HP Spectre ", 59999));
	        products.add(new Product("Lenovo ThinkPad", 89999));
	        products.add(new Product("Microsoft Surface", 109999));
	        products.add(new Product("Asus ZenBook ", 159999));
	        products.add(new Product("Acer Swift", 59999));
	        products.add(new Product("Razer Blade", 89999));
	        products.add(new Product("MSI Stealth", 109999));
	        products.add(new Product("Gigabyte Aero ", 159999));
	        products.add(new Product("Samsung Galaxy Book", 59999));
	        products.add(new Product("Huawei MateBook", 89999));
	        products.add(new Product("Xiaomi Mi Notebook", 109999));
	        products.add(new Product("Honor MagicBook ", 159999));
	        products.add(new Product("Acer Predator ", 59999));
	        products.add(new Product("Asus ROG", 89999));
	        products.add(new Product("Dell Alienware", 109999));
	        products.add(new Product("HP Omen", 159999));
	        products.add(new Product("Lenovo Legion", 59999));
	        products.add(new Product("MSI GE", 89999));
	        products.add(new Product("Gigabyte Aorus", 10999));
	        products.add(new Product("Samsung Odyssey ", 15999));
	        products.add(new Product("Huawei MateBook X Pro ", 59999));
	        products.add(new Product("Xiaomi Mi Notebook Pro", 8999));
	        

	        

	        cartModel = new DefaultListModel<>();
	        productList = new JList<>(products.stream().map(Product::getName).toArray(String[]::new));
	        productList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	        productList.addListSelectionListener(e -> {
	            int selectedIndex = productList.getSelectedIndex();
	            if (selectedIndex != -1) {
	                Product selectedProduct = products.get(selectedIndex);
	                cartModel.addElement(selectedProduct.getName() + " - $" + selectedProduct.getPrice());
	                totalPrice += selectedProduct.getPrice();
	                changeprice=totalPrice/2;
	                updateCartTextArea();
	            }
	        });

	        JScrollPane productScrollPane = new JScrollPane(productList);
	        productScrollPane.setPreferredSize(new Dimension(300, 400));

	        cartTextArea = new JTextArea(10, 30);
	        cartTextArea.setEditable(false);

	        JScrollPane cartScrollPane = new JScrollPane(cartTextArea);
	        
	        JButton back=new JButton(new ImageIcon("back.jpg"));
	        back.setBounds(1380,470,120,40);
	        back.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					Allbutton a13=new Allbutton();
					
				}
	        	
	        });


	        JButton checkoutButton = new JButton(new ImageIcon("Proceed to Buy.jpg"));
	        checkoutButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	radiobuttonnu clicko=new radiobuttonnu();
	                //JOptionPane.showMessageDialog(frame, "Total Price: $" + totalPrice, "successfully buyed", JOptionPane.INFORMATION_MESSAGE);
	            }
	        });

	        JPanel panel = new JPanel();
	        panel.setLayout(new BorderLayout());
	        panel.add(back);
	        panel.add(productScrollPane, BorderLayout.WEST);
	        panel.add(cartScrollPane, BorderLayout.CENTER);
	        panel.add(checkoutButton, BorderLayout.SOUTH);
	        
	        frame.setSize(1650,600);

	        frame.add(panel);
	        frame.setVisible(true);
	    }

	    public void updateCartTextArea() {
	        cartTextArea.setText("Shopping Cart:\n");
	        for (int i = 0; i < cartModel.getSize(); i++) {
	            cartTextArea.append(cartModel.getElementAt(i) + "\n");
	        }
	        cartTextArea.append("\nTotal Price: $" + changeprice);
	    }

	    public static void main(String[] args) {
	    	SwingUtilities.invokeLater(() -> new All());
	        
	    }

	    private static class Product {
	        private String name;
	        private double price;

	        public Product(String name, double price) {
	            this.name = name;
	            this.price = price;
	        }

	        public String getName() {
	            return name;
	        }

	        public double getPrice() {
	            return price;
	        }
	    }
	



}
