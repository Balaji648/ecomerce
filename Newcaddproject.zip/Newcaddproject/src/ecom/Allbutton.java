package ecom;
import javax.swing.*;
import java.awt.ActiveEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

public class Allbutton {
	JFrame allcollect;
	public Allbutton(){
		allcollect = new JFrame("collections");
		allcollect.setDefaultCloseOperation(allcollect.EXIT_ON_CLOSE);
		JButton fantasy=new JButton(new ImageIcon("bagsandshoes.jpg"));
		fantasy.setBounds(600,50,130,30);
		JLabel fantasy1=new JLabel("BAGS & SHOES");
		fantasy1.setBounds(620,20,150,30);
		fantasy.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ecommercemodified a1= new ecommercemodified();
				
			}
			
		});
		JButton dress=new JButton(new ImageIcon("Dresses.jpg"));
		dress.setBounds(600,130,130,30);
		JLabel dress1=new JLabel("DRESSES");
		dress1.setBounds(640,100,150,30);
		dress.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Dresses a2=new Dresses();
				
			} 
			
			
		});
		JButton mobile=new JButton(new ImageIcon("Mobile.jpg"));
		mobile.setBounds(600,210,130,30);
		JLabel mobile1=new JLabel("MOBILE");
		mobile1.setBounds(640,180,150,30);
		mobile.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Mobiles a3=new Mobiles();
				
				
			}});
		JButton accessories=new JButton(new ImageIcon("Accessories.jpg"));
		accessories.setBounds(600,280,130,30);
		JLabel accessories1=new JLabel("ACESSORIES");
		accessories1.setBounds(640,250,150,30);
		accessories.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Acessories a17=new Acessories();
			}
			
		});
		
		JButton laptop=new JButton(new ImageIcon("Laptop.jpg"));
		laptop.setBounds(600,340,130,30);
		JLabel laptop1=new JLabel("LAPTOP");
		laptop1.setBounds(640,310,150,30);
		laptop.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Laptop a4=new Laptop();
				
				
			}
			
		});
		JButton all=new JButton(new ImageIcon("All.jpg"));
		all.setBounds(600,420,130,30);
		JLabel all1=new JLabel("ALL");
		all1.setBounds(640,390,150,30);
		all.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				All a5=new All();
				
			}
			
		});
		JPanel pane =new JPanel();
		pane.setLayout(null);
		pane.add(fantasy);
		pane.add(fantasy1);
		pane.add(dress);
		pane.add(dress1);
		pane.add(mobile);
		pane.add(mobile1);
		pane.add(accessories);
		pane.add(accessories1);
		pane.add(laptop);
		pane.add(laptop1);
		pane.add(all);
		pane.add(all1);
		
		allcollect.add(pane);
		
		allcollect.setSize(1650,600);
		allcollect.setVisible(true);
		
	}
	public static void main(String[]args) {
		new Allbutton();
	}

}
