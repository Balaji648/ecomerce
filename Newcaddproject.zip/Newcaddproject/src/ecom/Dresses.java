package ecom;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Dresses {
	int op=0;
	  JFrame frame;
	    DefaultListModel<String> cartModel;
	    JList<String> productList;
	    JTextArea cartTextArea;

	    List<Product> products;
	    double totalPrice;
	    double changeprice;
	   


		public Dresses() {
	        frame = new JFrame("E-Commerce Application");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(800, 600);

	        products = new ArrayList<>();
	        products.add(new Product("Strip shirt green", 100));
	        products.add(new Product(" black shirt", 200));
	        products.add(new Product("white shirt ", 500));
	        products.add(new Product("whited black checked", 350));
	        products.add(new Product("blue party wear", 400));
	        products.add(new Product("blue jean ",678));
	        products.add(new Product("ice blue jean ", 500));
	        products.add(new Product("fadded jean", 800));
	        products.add(new Product("trendy shirts of grey", 430));
	        products.add(new Product("cotton shirt ", 430));
	        products.add(new Product("Lycra shirt",340));
	        products.add(new Product("lycra ice blue shirt",320));
	        products.add(new Product("lycra blue",659));
	        products.add(new Product("Tonned Shirt ", 1599));
	        products.add(new Product("Jean Shirt ", 599));
	        products.add(new Product("Polofit Tshirt", 899));
	        products.add(new Product("Lycra Tshirt", 1099));
	        products.add(new Product("full Hand shirt ", 599));
	        products.add(new Product("HalfHand partywear ", 300));
	        

	        cartModel = new DefaultListModel<>();
	        productList = new JList<>(products.stream().map(Product::getName).toArray(String[]::new));
	        productList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	        productList.addListSelectionListener(e -> {
	            int selectedIndex = productList.getSelectedIndex();
	            System.out.println("selectedproduct"+cartModel);
	            if (selectedIndex != -1) {
	                Product selectedProduct = products.get(selectedIndex);
	                cartModel.addElement(selectedProduct.getName() + " - $" + selectedProduct.getPrice());
	                totalPrice += selectedProduct.getPrice();
	                changeprice=totalPrice/2;
	                updateCartTextArea();
	            }
	        });

	        JScrollPane productScrollPane = new JScrollPane(productList);
	        productScrollPane.setPreferredSize(new Dimension(300, 400));

	        cartTextArea = new JTextArea(10, 30);
	        cartTextArea.setEditable(false);

	        JScrollPane cartScrollPane = new JScrollPane(cartTextArea);
	        
	        JButton back=new JButton(new ImageIcon("back.jpg"));
	        back.setBounds(1380,470,120,40);
	        back.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					Allbutton a9=new Allbutton();
					
				}
	        	
	        });


	        JButton checkoutButton = new JButton(new ImageIcon("Proceed to Buy.jpg"));
	        
	        checkoutButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	radiobuttonnu clicko=new radiobuttonnu();
	               // JOptionPane.showMessageDialog(frame, "Total Price: $" + totalPrice, "successfully buyed", JOptionPane.INFORMATION_MESSAGE);
	            }
	        });

	        JPanel panel = new JPanel();
	        panel.setLayout(new BorderLayout());
	        panel.add(back);
	        panel.add(productScrollPane, BorderLayout.WEST);
	        panel.add(cartScrollPane, BorderLayout.CENTER);
	        panel.add(checkoutButton, BorderLayout.SOUTH);
	        

	        frame.setSize(1650,600);
	        frame.add(panel);
	        frame.setVisible(true);
	    }

	    public void updateCartTextArea() {
	        cartTextArea.setText("Shopping Cart:\n");
	        for (int i = 0; i < cartModel.getSize(); i++) {
	            cartTextArea.append(cartModel.getElementAt(i) + "\n");
	        }
	        cartTextArea.append("\nTotal Price: $" +changeprice);
	    }

	    public static void main(String[] args) {
	    	
	    	SwingUtilities.invokeLater(() -> new Dresses());
	        
	    }

	    private static class Product {
	        private String name;
	        private double price;

	        public Product(String name, double price) {
	            this.name = name;
	            this.price = price;
	        }

	        public String getName() {
	            return name;
	        }

	        public double getPrice() {
	            return price;
	        }
	    }
	



}
